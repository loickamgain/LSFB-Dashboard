from fastapi import FastAPI, Query, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from typing import List
import pandas as pd
import os
import json
from schema.models_cont import ContVideo, ContPose, WordAnnotation
from schema.models_isol import IsolVideo, IsolPose, IsolInstance
from database import get_db_cont, get_db_isol

# Fonction pour décoder les chaînes contenant des caractères Unicode
def decode_unicode_string(encoded_str: str) -> str:
    return bytes(encoded_str, "utf-8").decode("unicode_escape")

app = FastAPI()

# Route pour la recherche dans `cont`
@app.get("/search_word_cont/{word}", response_model=List[dict])
async def search_word_cont(word: str, db_cont: AsyncSession = Depends(get_db_cont)):
    # Recherche dans la base de données `cont`
    query_cont = await db_cont.execute(
        select(ContVideo, ContPose, WordAnnotation)
        .join(ContPose, ContPose.instance_id == ContVideo.id)
        .join(WordAnnotation, WordAnnotation.instance_id == ContVideo.id)
        .filter(or_(
            WordAnnotation.word.ilike(f"%{word}%"),
            WordAnnotation.word == word
        ))
        .options(selectinload(ContVideo.poses))  # Charger les poses associées
    )
    results_cont = query_cont.all()

    response = []

    # Traitement des résultats pour `cont`
    for video, pose, annotation in results_cont:
        poses = []
        for body_part in ['face', 'left_hand', 'right_hand', 'pose']:
            pose_path = os.path.join('path_to_cont_poses', f"{video.id}_{body_part}.npy")  # Mettez à jour le chemin de votre dossier de poses
            if os.path.exists(pose_path):
                poses.append({
                    "pose_part": body_part,
                    "pose_path": pose_path
                })
        
        if poses:
            video_data = {
                "video_id": video.id,
                "video_path": video.path,
                "base": "cont",  # Différencier la base de données
                "pose": {
                    "pose_part": pose.pose_part,
                    "pose_path": pose.pose_path,
                    "video_segment": {
                        "start_time": annotation.start_time,
                        "end_time": annotation.end_time
                    }
                },
                "poses": poses
            }
            response.append(video_data)

    # Recherche dans les sous-titres
    subtitles_file_path = os.path.join('path_to_cont_annotations', 'subtitles.json')  # Mettez à jour le chemin de votre fichier de sous-titres
    assert os.path.exists(subtitles_file_path), f"Le fichier 'subtitles.json' n'existe pas : {subtitles_file_path}"
    
    with open(subtitles_file_path, 'r') as f:
        subtitles_data = json.load(f)

    for instance_id, subtitles in subtitles_data.items():
        for subtitle in subtitles:
            decoded_value = decode_unicode_string(subtitle['value'])
            if word.lower() in decoded_value.lower():
                poses = []
                for body_part in ['face', 'left_hand', 'right_hand', 'pose']:
                    pose_path = os.path.join('path_to_cont_poses', f"{instance_id}_{body_part}.npy")
                    if os.path.exists(pose_path):
                        poses.append({
                            "pose_part": body_part,
                            "pose_path": pose_path
                        })

                if poses:
                    video_data = {
                        "video_id": instance_id,
                        "video_path": os.path.join('path_to_cont_videos', f"{instance_id}.mp4"),
                        "base": "cont",
                        "poses": poses
                    }
                    response.append(video_data)

    return response

# Route pour la recherche dans `isol`
@app.get("/search_word_isol/{word}", response_model=List[dict])
async def search_word_isol(word: str, db_isol: AsyncSession = Depends(get_db_isol)):
    # Recherche dans le fichier `instance.csv` de `isol`
    isol_folder_path = r"E:\lsfb dataset\isol"  # Remplacez par le bon chemin de votre dossier isol
    instances_csv_path = os.path.join(isol_folder_path, 'instance.csv')
    assert os.path.exists(instances_csv_path), f"Le fichier 'instance.csv' n'existe pas : {instances_csv_path}"
    
    instances_df = pd.read_csv(instances_csv_path, delimiter=',')  
    instances_data = instances_df.to_dict(orient='records')

    # Recherche des vidéos dans `isol` où le mot est présent
    results_isol = []
    for instance_data in instances_data:
        if word.lower() in instance_data.get('id', '').lower() or word.lower() in instance_data.get('sign', '').lower():
            video_name = instance_data['id']
            video_file = f"{video_name}.mp4"
            video_path = os.path.join(isol_folder_path, 'videos', video_file)

            if os.path.exists(video_path):
                # Ajouter toutes les poses associées à cette vidéo
                poses = []
                # Rechercher dans les 4 sous-dossiers (face, left_hand, right_hand, pose)
                for body_part in ['face', 'left_hand', 'right_hand', 'pose']:
                    pose_path = os.path.join(isol_folder_path, 'poses', body_part, f"{video_name}.npy")
                    if os.path.exists(pose_path):
                        poses.append({
                            "pose_part": body_part,
                            "pose_path": pose_path
                        })

                if poses:
                    results_isol.append({
                        "video_id": video_name,
                        "video_path": video_path,
                        "base": "isol",
                        "poses": poses
                    })

    return results_isol
