from fastapi import APIRouter, Query, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from database.db_init import get_db_cont, get_db_isol
from schema.models_cont import ContInstance, ContVideo, WordAnnotation
from schema.models_isol import IsolInstance, IsolVideo

# 1) Créer un router
router = APIRouter()
templates = Jinja2Templates(directory="templates")

# 2) Définir les routes
# --- Pages HTML simples ---
@router.get("/about.html", response_class=HTMLResponse)
async def read_about(request: Request):
    return templates.TemplateResponse("about.html", {"request": request})

@router.get("/contact.html", response_class=HTMLResponse)
async def read_contact(request: Request):
    return templates.TemplateResponse("contact.html", {"request": request})

@router.get("/lsfb.html", response_class=HTMLResponse)
async def read_lsfb(request: Request):
    return templates.TemplateResponse("lsfb.html", {"request": request})

@router.get("/results.html", response_class=HTMLResponse)
async def read_results_html(request: Request):
    # Ce n’est qu’une page statique si vous voulez l’afficher directement
    return templates.TemplateResponse("results.html", {"request": request})

@router.get("/suggestions.html", response_class=HTMLResponse)
async def read_suggestions(request: Request):
    return templates.TemplateResponse("suggestions.html", {"request": request})

@router.get("/video_view.html", response_class=HTMLResponse)
async def read_video_view(request: Request):
    return templates.TemplateResponse("video_view.html", {"request": request})


# --- Route de recherche : /results ---
@router.get("/results", response_class=HTMLResponse)
async def search_results(
    request: Request,
    term: str = Query("", description="Mot ou phrase à rechercher"),
    dataset: str = Query("", description="cont ou isol ou ''"),
    signer: str = Query("", description="Identifiant signataire (ex: 102)"),
    hand_type: str = Query("", description="left, right, both ou ''"),
    sign_type: str = Query("", description="normal, special ou ''"),
    session_id: str = Query("", description="Session pour cont"),
    task_id: str = Query("", description="Task/Catégorie pour cont"),
    db_cont: AsyncSession = Depends(get_db_cont),
    db_isol: AsyncSession = Depends(get_db_isol),
):
    """
    Page qui affiche les résultats d'une recherche avec filtres.
    Si aucun résultat n'est trouvé, on affiche "Aucun résultat trouvé".
    """

    term_lower = term.strip().lower()
    cont_videos = []
    isol_videos = []

    # --------------------------------------------
    # Recherche sur "CONT"
    # --------------------------------------------
        #on inclut 'cont' si dataset='' ou dataset='cont'
        # Exemple : on veut retrouver les instances qui matchent 'term'
        #  - si vous cherchez dans WordAnnotation, sous-titres, etc.
        #  - si vous cherchez juste instance_id ilike f"%{term_lower}%"
        # Filtrer sur sign_type, hand_type => via WordAnnotation
        # Filtrer sur signer => ContInstance.signer_id
        # Filtrer sur session => ContInstance.session_id
        # Filtrer sur task => ContInstance.task_id"""

    if dataset in ["", "cont"]:
        query_cont = select(ContVideo).join(ContInstance)

        if term_lower:
            query_cont = query_cont.filter(ContInstance.id.ilike(f"%{term_lower}%"))
        if signer:
            query_cont = query_cont.filter(ContInstance.signer_id == signer)
        if session_id:
            query_cont = query_cont.filter(ContInstance.session_id == session_id)
        if task_id:
            query_cont = query_cont.filter(ContInstance.task_id == task_id)

        # Filtre sur main (hand_type) et sign_type => via WordAnnotation
        #   On fait un join sur WordAnnotation, s'il existe
        #   Ex. : select(ContVideo).join(ContInstance).join(WordAnnotation)
        #   puis .filter(WordAnnotation.hand_type == hand_type)
        #   /!\ Il faut ajuster la logique, car 1 instance peut avoir plusieurs WordAnnotation
        #   => group by? distinct? etc.

        if hand_type or sign_type:
            # On fait un JOIN sur WordAnnotation si main ou type de signe est demandé
            query_cont = query_cont.join(WordAnnotation, WordAnnotation.instance_id == ContInstance.id)
            if hand_type:
                query_cont = query_cont.filter(WordAnnotation.hand_type == hand_type)
            if sign_type:
                query_cont = query_cont.filter(WordAnnotation.sign_type == sign_type)

        result_cont = await db_cont.execute(query_cont)
        cont_videos = result_cont.scalars().all()

    # --------------------------------------------
    # Recherche sur "ISOL"
    # --------------------------------------------
        # Filtre sur la base isol
        # Filtre sur "term" => ex. .filter(IsolInstance.sign.ilike(...)) 
        # Filtre sur signer => IsolInstance.signer

    if dataset in ["", "isol"]:
        query_isol = select(IsolVideo).join(IsolInstance)

        if term_lower:
            query_isol = query_isol.filter(IsolInstance.sign.ilike(f"%{term_lower}%"))
        if signer:
            query_isol = query_isol.filter(IsolInstance.signer == signer)

        result_isol = await db_isol.execute(query_isol)
        isol_videos = result_isol.scalars().all()

    no_results = (len(cont_videos) == 0) and (len(isol_videos) == 0)

    return templates.TemplateResponse(
        "results.html",
        {
            "request": request,
            "term": term,
            "dataset": dataset,
            "signer": signer,
            "hand_type": hand_type,
            "sign_type": sign_type,
            "session_id": session_id,
            "task_id": task_id,
            "cont_videos": cont_videos,
            "isol_videos": isol_videos,
            "no_results": no_results,
        },
    )
