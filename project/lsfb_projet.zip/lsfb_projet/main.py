import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from database.db_init import get_db_cont, get_db_isol
from route.route import router  # Import du router défini dans route.py

app = FastAPI()
app.include_router(router)  # on inclut le router

templates = Jinja2Templates(directory="templates")

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


@app.middleware("http")
async def log_requests(request: Request, call_next):
    logging.info(f"🔹 Requête : {request.method} {request.url}")
    response = await call_next(request)
    logging.info(f"🔹 Réponse : {response.status_code}")
    return response


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logging.error(f"❌ Erreur interne : {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={"message": "Une erreur interne est survenue. Veuillez réessayer plus tard."},
    )


# Page d'accueil accessible via http://127.0.0.1:8000/
@app.get("/", response_class=HTMLResponse)
async def read_home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


# Même page d’accueil, accessible via /index.html
@app.get("/index.html", response_class=HTMLResponse)
async def read_index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


if __name__ == "__main__":
    get_db_cont()
    get_db_isol()
    uvicorn.run(app, host="127.0.0.1", port=8000)
